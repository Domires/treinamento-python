# Exemplo: tipagem dinâmica (o tipo é inferido em tempo de execução)
toneladas = 100          # toneladas é int
print(type(toneladas))   # <class 'int'>

produto = "Polyblen"  # a mesma ideia de variável, agora com texto
print(type(produto))      # <class 'str'>

# Exemplo: tipagem forte (não há coerção automática entre tipos)
var1 = 100
var2 = "100"
total = var1 + var2 # número + texto -> erro!

# Para somar, é necessário converter explicitamente:
# total = var1 + int(var2)
# print(total)