"""
=============================================================
 17. PANDAS — SELEÇÃO E INDEXAÇÃO
=============================================================

Formas de selecionar dados em um DataFrame:

    df['coluna']      -> seleciona uma coluna (Series)
    df[['c1', 'c2']]  -> seleciona várias colunas (DataFrame)
    df.loc[...]       -> seleção por RÓTULO  (label)
    df.iloc[...]      -> seleção por POSIÇÃO (inteiro)
"""

import pandas as pd

df = pd.read_csv('producao.csv')


# ---------------------------------------------------------------
# Selecionando COLUNAS
# ---------------------------------------------------------------
print(df['produto'])                       # uma coluna -> Series
print(df[['produto', 'ton_produzido']])    # várias colunas -> DataFrame


# ---------------------------------------------------------------
# .loc -> seleção por RÓTULO (índice e nome de coluna)
# ---------------------------------------------------------------
print(df.loc[0])                       # linha de rótulo 0
print(df.loc[0, 'produto'])            # célula específica
print(df.loc[0:3, ['produto', 'ton_produzido']])  # fatia de linhas + colunas
#  Atenção: em .loc o fim do intervalo é INCLUSIVO (0:3 traz as linhas 0,1,2,3)


# ---------------------------------------------------------------
# .iloc -> seleção por POSIÇÃO (como em listas)
# ---------------------------------------------------------------
print(df.iloc[0])          # primeira linha
print(df.iloc[0, 2])       # linha 0, coluna 2 (produto)
print(df.iloc[0:3])        # primeiras 3 linhas (fim EXCLUSIVO: 0,1,2)
print(df.iloc[-1])         # última linha
print(df.iloc[:, 0:3])     # todas as linhas, colunas 0 a 2


# ---------------------------------------------------------------
# Definindo uma coluna como índice
# ---------------------------------------------------------------
df_idx = df.set_index('ordem_producao')
print(df_idx.loc['OP-1001'])  # agora dá para buscar pelo código da OP


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Mostre apenas as colunas 'ordem_producao' e 'ton_produzido'
#    das 5 primeiras ordens.

# Resposta
print(df.loc[0:4, ['ordem_producao', 'ton_produzido']])
