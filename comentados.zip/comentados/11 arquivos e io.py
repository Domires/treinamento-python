"""
=============================================================
 11. ARQUIVOS E I/O
=============================================================

Arquivos são representados por objetos do tipo `file`.

MODOS DE ABERTURA:
    'r' — leitura (default)
    'w' — gravação (sobrescreve)
    'a' — adição (append)
    'b' — modo binário (combina com os anteriores: 'rb', 'wb')

OBS: para planilhas/tabelas (CSV, Excel) usaremos o pandas na Parte 2,
que é muito mais prático. Aqui vemos a leitura/escrita "crua" de texto.
"""

import sys
import os.path


# ---------------------------------------------------------------
# Exemplo: gravar um relatório simples de produção em texto
# ---------------------------------------------------------------
producao = [('OP-1001', 'NPK 10-10-10', 470),
            ('OP-1002', 'Ureia', 590),
            ('OP-1003', 'MAP', 400)]

relatorio = open('relatorio_producao.txt', 'w')
for codigo, produto, ton in producao:
    relatorio.write('%s;%s;%d\n' % (codigo, produto, ton))
relatorio.close()


# ---------------------------------------------------------------
# Exemplo: ler o relatório linha a linha
# ---------------------------------------------------------------
relatorio = open('relatorio_producao.txt')
for linha in relatorio:
    sys.stdout.write(linha)
relatorio.close()


# ---------------------------------------------------------------
# Exemplo: ler todas as linhas de uma vez como lista
# ---------------------------------------------------------------
print(open('relatorio_producao.txt').readlines())


# ---------------------------------------------------------------
# Exemplo: validar a existência de um arquivo antes de abrir
# ---------------------------------------------------------------
# Descomente para testar a leitura interativa de um arquivo:
#
# nome = input('Nome do arquivo: ').strip()
# if not os.path.exists(nome):
#     print('Arquivo não encontrado. Tente outra vez...')
#     sys.exit()
#
# for i, linha in enumerate(open(nome)):
#     print(i + 1, linha,)


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Acrescente (modo 'a') a OP-1004 (KCl, 540 t) ao relatório e
#    depois imprima quantas linhas o arquivo passou a ter.

# Resposta
with open('relatorio_producao.txt', 'a') as f:
    f.write('OP-1004;KCl;540\n')

linhas = open('relatorio_producao.txt').readlines()
print("Total de linhas:", len(linhas))
