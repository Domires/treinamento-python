"""
=============================================================
 15. PANDAS — DATAFRAME (CRIAÇÃO E INSPEÇÃO)
=============================================================

DataFrame é uma tabela 2D rotulada (linhas + colunas).
É o objeto central do pandas — equivalente a uma planilha de produção.
"""

import pandas as pd


# ---------------------------------------------------------------
# Criação a partir de um dicionário (chave = nome da coluna)
# ---------------------------------------------------------------
df = pd.DataFrame({
    'produto': ['NPK 10-10-10', 'Ureia', 'MAP', 'KCl'],
    'linha': ['Granulacao', 'Mistura', 'Granulacao', 'Mistura'],
    'ton_produzido': [470, 590, 400, 540],
    'lotes_aprovados': [19, 18, 14, 21]
})
print(df)


# ---------------------------------------------------------------
# Criação a partir de uma lista de listas (informando as colunas)
# ---------------------------------------------------------------
dados = [
    ['NPK 10-10-10', 470],
    ['Ureia', 590],
    ['MAP', 400],
]
df2 = pd.DataFrame(dados, columns=['produto', 'ton_produzido'])
print(df2)


# ---------------------------------------------------------------
# INSPEÇÃO — métodos essenciais para conhecer os dados
# ---------------------------------------------------------------
print(df.head(2))    # primeiras linhas (default 5)
print(df.tail(2))    # últimas linhas
print(df.shape)      # (linhas, colunas)
print(df.columns)    # nomes das colunas
print(df.dtypes)     # tipo de cada coluna
print(df.index)      # índice das linhas

print(df.info())     # resumo: tipos, nulos, memória
print(df.describe()) # estatísticas das colunas numéricas


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Crie um DataFrame com 3 ordens de produção (codigo, produto,
#    ton_produzido) e imprima quantas linhas e colunas ele tem.

# Resposta
ops = pd.DataFrame({
    'codigo': ['OP-2001', 'OP-2002', 'OP-2003'],
    'produto': ['Ureia', 'MAP', 'KCl'],
    'ton_produzido': [580, 430, 500]
})
print("Linhas x Colunas:", ops.shape)
