"""
=============================================================
 18. PANDAS — FILTROS (BOOLEAN INDEXING)
=============================================================

Filtrar = selecionar linhas que satisfazem uma condição.
A condição gera uma máscara booleana (True/False por linha),
e o DataFrame retorna apenas as linhas True.

OPERADORES (use & | ~ e SEMPRE parênteses em cada condição):
    &   -> E      (and)
    |   -> OU     (or)
    ~   -> NÃO    (not)
"""

import pandas as pd

df = pd.read_csv('producao.csv')


# ---------------------------------------------------------------
# Filtro simples
# ---------------------------------------------------------------
mask = df['produto'] == 'Ureia'
print(df[mask])

# Forma direta (sem variável): paradas longas (> 40 min)
print(df[df['tempo_parada_min'] > 40])


# ---------------------------------------------------------------
# Múltiplas condições (cada condição entre parênteses)
# ---------------------------------------------------------------
# Granulação com produção abaixo de 450 t
print(df[(df['linha'] == 'Granulacao') & (df['ton_produzido'] < 450)])

# Turno A ou turno B
print(df[(df['turno'] == 'A') | (df['turno'] == 'B')])

# Tudo que NÃO é da linha Mistura
print(df[~(df['linha'] == 'Mistura')])


# ---------------------------------------------------------------
# Métodos auxiliares de filtro
# ---------------------------------------------------------------
# .isin() -> valor pertence a uma lista
print(df[df['produto'].isin(['NPK 10-10-10', 'MAP'])])

# .between() -> valor dentro de um intervalo (inclusivo)
print(df[df['ton_produzido'].between(450, 550)])

# .str.contains() -> filtro por texto (todas as ordens de NPK)
print(df[df['produto'].str.contains('NPK')])

# .query() -> filtro com sintaxe de expressão (mais legível)
print(df.query("linha == 'Granulacao' and tempo_parada_min > 30"))


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Liste as ordens em que houve refugo, ou seja, onde
#    lotes_aprovados é MENOR que lotes_total.

# Resposta
print(df[df['lotes_aprovados'] < df['lotes_total']])
