"""
=============================================================
 8. FUNÇÕES
=============================================================

Funções são blocos de código identificados por um nome, que podem
receber parâmetros pré-determinados.

Características:
- Podem ou não retornar um valor
- Aceitam Doc Strings
- Têm namespace próprio (escopo local)
- Aceitam parâmetros opcionais com valor padrão
"""


# ---------------------------------------------------------------
# Exemplo: função com docstring e parâmetro opcional
# ---------------------------------------------------------------
def calcular_oee(disponibilidade, performance, qualidade=1.0):
    """
    Calcula o OEE (Overall Equipment Effectiveness).

    args:
        disponibilidade (float) — fração de 0 a 1 (tempo operando / planejado)
        performance     (float) — fração de 0 a 1 (produzido / esperado)
        qualidade       (float) — fração de 0 a 1 (aprovados / total). Padrão 1.0
    return:
        OEE como fração de 0 a 1
    """
    return disponibilidade * performance * qualidade

oee = calcular_oee(0.94, 0.95, 0.97)
print(f"OEE: {oee:.1%}")          # usa os três fatores
print(f"OEE: {calcular_oee(0.94, 0.95):.1%}")  # qualidade assume o padrão 1.0


# ---------------------------------------------------------------
# Exemplo: função que retorna booleano
# ---------------------------------------------------------------
def atingiu_meta(ton_produzido, ton_planejado):
    if ton_produzido >= ton_planejado:
        return True
    else:
        return False

print(atingiu_meta(540, 500))   # True
print(atingiu_meta(470, 500))   # False


# ---------------------------------------------------------------
# Exemplo AVANÇADO / OPCIONAL: recursão (função que chama a si mesma)
# ---------------------------------------------------------------
# Raro no dia a dia de negócio; incluído só como curiosidade.
def fatorial(num):
    """Calcula o fatorial de um número (implementação recursiva)."""
    if num <= 1:
        return 1
    return num * fatorial(num - 1)

print(fatorial(5))  # 120


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Crie uma função 'rendimento(ton_produzido, ton_planejado)' que
#    retorne o aproveitamento em porcentagem (0 a 100).
# 2) Teste com 480 produzidas de 500 planejadas (deve dar 96.0).

# Resposta
def rendimento(ton_produzido, ton_planejado):
    return ton_produzido / ton_planejado * 100

print(rendimento(480, 500))  # 96.0
