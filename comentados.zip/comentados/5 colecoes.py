"""
=============================================================
 5. COLEÇÕES
=============================================================

Referência: https://docs.python.org/3/tutorial/datastructures.html
"""


# ---------------------------------------------------------------
# LISTAS
# ---------------------------------------------------------------
# Coleções HETEROGÊNEAS e MUTÁVEIS de objetos (podem conter qualquer
# tipo, inclusive outras listas). Suportam fatiamento (slicing).
# Sintaxe: lista = [1, 2, 3]

toneladas = [470, 590, 400]
registro = ["NPK 10-10-10", 470.5, True]   # produto, toneladas, aprovado?
lista_de_listas = [toneladas, registro, []]

print(toneladas)
print(registro)
print(lista_de_listas)

# Acesso por índice aninhado
print(lista_de_listas[1][0])   # "NPK 10-10-10"

# Métodos comuns de lista
produtos = ['NPK 10-10-10', 'Ureia', 'MAP', 'KCl', 'Superfosfato Simples']

for produto in produtos:
    print(produto)

produtos.append('DAP')        # adiciona ao fim
produtos.remove('KCl')        # remove por valor
produtos.sort()               # ordena in-place (alfabético)

print(produtos)

# enumerate — índice + valor
for i, produto in enumerate(produtos):
    print(i + 1, '=>', produto)

# fila de ordens de produção: processa e remove da frente (pop(0))
fila_ops = ['OP-1001', 'OP-1002', 'OP-1003']
while fila_ops:
    print('Processando', fila_ops.pop(0), '- restam', len(fila_ops))


# ---------------------------------------------------------------
# TUPLAS
# ---------------------------------------------------------------
# Semelhantes às listas, porém IMUTÁVEIS: não se pode acrescentar,
# apagar ou reatribuir itens.
# Sintaxe: tupla = (a, b, c)
#   - Tupla com um único elemento: T1 = (1,)  — a vírgula é obrigatória
#   - Conversão: tuple(lista) / list(tupla)
#
# Tuplas são convenientes para retornar múltiplos valores de uma função:

def indicadores(ton_planejado, ton_produzido):
    """Retorna (diferença, aproveitamento %, atingiu meta?)."""
    diferenca = ton_planejado - ton_produzido
    aproveitamento = ton_produzido / ton_planejado * 100
    atingiu = ton_produzido >= ton_planejado
    return diferenca, aproveitamento, atingiu

resultado = indicadores(500, 470)
dif, aprov, _ = indicadores(500, 470)   # _ ignora o terceiro valor

print(resultado)
print(dif)
print(aprov)


# ---------------------------------------------------------------
# DICIONÁRIOS
# ---------------------------------------------------------------
# Coleção de pares CHAVE-VALOR, mutável. A chave deve ser imutável;
# o valor pode ser qualquer tipo.
# A partir do Python 3.7, a ordem de inserção é garantida.
# Sintaxe: dicionario = {'chave': valor}

ordem = {'codigo': 'OP-1001', 'produto': 'NPK 10-10-10', 'toneladas': 470}
print(ordem['produto'])         # acesso por chave
print(ordem.get('turno'))       # get -> None se a chave não existe (não dá erro)
ordem['toneladas'] = 480        # atualização de valor

for chave, valor in ordem.items():   # iterando chaves e valores
    print(chave, valor)

ordem['linha'] = 'Granulacao'   # inserindo nova chave
for chave, valor in ordem.items():
    print(chave, valor)

del ordem['toneladas']          # apaga chave e valor
print(ordem)

ordem.clear()                   # esvazia o dicionário
print(ordem)

# Criando com construtor dict()
catalogo = dict(
    produto=['NPK 10-10-10', 'Ureia', 'MAP'],
    linha=['Granulacao', 'Mistura', 'Granulacao'],
    capacidade_t=[500, 600, 450]
)
print(catalogo)


# ---------------------------------------------------------------
# SETS (CONJUNTOS)
# ---------------------------------------------------------------
# Coleção NÃO ORDENADA de elementos ÚNICOS. Útil para remover
# duplicatas e operações de conjuntos (união, interseção, diferença).
# Sintaxe: conjunto = {1, 2, 3}

produzidos = {'NPK 10-10-10', 'Ureia', 'NPK 10-10-10', 'MAP', 'MAP'}
print(produzidos)   # duplicatas removidas

linha_granulacao = {'NPK 10-10-10', 'MAP', 'KCl'}
linha_mistura    = {'Ureia', 'KCl', 'Superfosfato Simples'}
print('Em ambas as linhas :', linha_granulacao & linha_mistura)  # interseção
print('Em qualquer linha  :', linha_granulacao | linha_mistura)  # união
print('Só na granulação   :', linha_granulacao - linha_mistura)  # diferença


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) A partir da lista de produtos produzidos no dia (com repetição),
#    descubra quantos produtos DISTINTOS foram produzidos.
# 2) No dicionário 'op', troque a 'linha' para "Mistura" e adicione
#    a chave 'turno' com valor "B".

produzidos_dia = ['Ureia', 'MAP', 'Ureia', 'NPK 10-10-10', 'MAP', 'Ureia']
op = {'codigo': 'OP-2001', 'produto': 'Ureia', 'linha': 'Granulacao'}

# Resposta
print("Produtos distintos:", len(set(produzidos_dia)))

op['linha'] = 'Mistura'
op['turno'] = 'B'
print(op)
