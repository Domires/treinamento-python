"""
=============================================================
 12. PROGRAMAÇÃO FUNCIONAL
=============================================================

Estilo que trata funções como "peças" aplicadas a coleções.
Útil para transformar listas de dados de produção em poucas linhas.
"""

from functools import reduce


# ---------------------------------------------------------------
# lambda  (AVANÇADO / OPCIONAL)
# ---------------------------------------------------------------
# Função anônima de expressão única. Ex.: converter toneladas em kg.
para_kg = lambda toneladas: toneladas * 1000
print(para_kg(0.47), 'kg')  # 470.0 kg


# ---------------------------------------------------------------
# map, filter, reduce
# ---------------------------------------------------------------
producao = [470, 590, 400, 540, 460]   # toneladas por OP

# map -> aplica uma função a cada elemento (toneladas -> kg)
em_kg = list(map(lambda t: t * 1000, producao))

# filter -> mantém só os elementos que passam na condição (>= 500 t)
acima_meta = list(filter(lambda t: t >= 500, producao))

# reduce -> reduz a lista a um único valor (soma total)  [AVANÇADO]
total = reduce(lambda a, b: a + b, producao)

print('Em kg       :', em_kg)
print('Acima de 500:', acima_meta)
print('Total       :', total, 't')


# ---------------------------------------------------------------
# zip -> combina duas listas posição a posição
# ---------------------------------------------------------------
produtos = ['NPK 10-10-10', 'Ureia', 'MAP']
toneladas = [470, 590, 400]

for produto, ton in zip(produtos, toneladas):
    print(f"{produto}: {ton} t")


# ---------------------------------------------------------------
# COMPREHENSIONS
# ---------------------------------------------------------------
# Forma pythônica e concisa de criar coleções.

# List comprehension — converte toneladas em kg
em_kg = [t * 1000 for t in producao]
print(em_kg)

# Com condição — só as OPs que bateram 500 t
acima_meta = [t for t in producao if t >= 500]
print(acima_meta)

# Dict comprehension — produto -> toneladas
mapa = {prod: ton for prod, ton in zip(produtos, toneladas)}
print(mapa)

# Set comprehension — linhas distintas
linhas = {'Granulacao', 'Mistura', 'Granulacao'}
distintas = {l.upper() for l in linhas}
print(distintas)


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Com list comprehension, crie a lista do aproveitamento (%) de cada
#    OP, dado produzido e planejado (use zip).

produzido  = [470, 590, 400, 540]
planejado  = [500, 600, 450, 550]

# Resposta
aproveitamento = [round(p / m * 100, 1) for p, m in zip(produzido, planejado)]
print(aproveitamento)   # [94.0, 98.3, 88.9, 98.2]
