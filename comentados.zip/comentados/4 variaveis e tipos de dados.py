"""
=============================================================
 4. VARIÁVEIS E TIPOS DE DADOS
=============================================================

Variáveis em Python são criadas através de atribuição
(tipagem por atribuição):

- O nome deve começar com uma letra ou `_`
- Python é case sensitive: `produto` != `Produto`
- Permite caracteres especiais, mas não é uma boa prática

Os tipos mais comuns são builtins — sem necessidade de importar pacotes.
"""


# ---------------------------------------------------------------
# TIPOS NUMÉRICOS
# ---------------------------------------------------------------
print('int(99.7) =', int(99.7))           # real para inteiro (trunca)
print('float(500) =', float(500))         # inteiro para real
print('470 / 480 * 100 =', 470 / 480 * 100)  # % de aproveitamento de tempo
print('595 // 50 =', 595 // 50)            # quantos lotes inteiros de 50 t

# NÚMERO COMPLEXO (avançado / opcional — raro no dia a dia de negócio)
c = 4 + 3j
print('c =', c)
print('Parte real:', c.real)
print('Parte imaginária:', c.imag)
print('Conjugado:', c.conjugate())


# ---------------------------------------------------------------
# OPERADORES ARITMÉTICOS
# ---------------------------------------------------------------
# | Operador | Descrição        | Exemplo       |
# |----------|------------------|---------------|
# | +        | Adição           | 3 + 2 = 5     |
# | -        | Subtração        | 3 - 2 = 1     |
# | *        | Multiplicação    | 3 * 2 = 6     |
# | /        | Divisão          | 3 / 2 = 1.5   |
# | //       | Divisão inteira  | 3 // 2 = 1    |
# | %        | Módulo (resto)   | 3 % 2 = 1     |
# | **       | Exponenciação    | 3 ** 2 = 9    |

ton_planejado = 500
ton_produzido = 470
print('Diferença       :', ton_planejado - ton_produzido, 't')
print('Aproveitamento  :', ton_produzido / ton_planejado * 100, '%')
print('Lotes de 50 t   :', ton_produzido // 50)
print('Sobra fora lote :', ton_produzido % 50, 't')


# ---------------------------------------------------------------
# STRINGS
# ---------------------------------------------------------------
# Strings são IMUTÁVEIS: não é possível modificar caracteres
# individuais diretamente.

produto = 'Ureia'
print('Produto: ' + produto)                         # concatenação
print('nome %s tem %d letras' % (produto, len(produto)))  # interpolação com %
for ch in produto:
    print(ch)

# Formatação com o operador %
print('Turno %02d início %02d:%02d' % (1, 6, 0))
print('OEE: %.1f%%, Refugo: %.2e' % (85.3, 0.00314))

# Formatação com .format()
producoes = [('NPK 10-10-10', 'Granulacao', 470),
             ('Ureia', 'Mistura', 590)]

msg = '{0} na linha {1} produziu {2} t'

for prod, linha, ton in producoes:
    print(msg.format(prod, linha, ton))

# f-strings (Python 3.6+) — forma mais conveniente de formatar strings
ton_produzido = 470
ton_planejado = 500
oee = ton_produzido / ton_planejado
resultado = f"{produto}: produziu {ton_produzido} t de {ton_planejado} t (eficiência {oee:.1%})"
print(resultado)

# \ dentro de strings é interpretado como caractere especial
# Use raw strings (r"...") para evitar isso (ex.: caminhos de arquivo)
print('C:\producao\novo')    # \n e \p podem causar surpresa
print(r'C:\producao\novo')   # imprime literalmente

# Slicing — fatiamento de strings (ex.: código da ordem de produção)
op = "OP-1001"
print(op[0])     # O       — primeiro caractere
print(op[-1])    # 1       — último caractere
print(op[0:2])   # OP      — do índice 0 ao 1
print(op[3:])    # 1001    — só o número da ordem


# ---------------------------------------------------------------
# TIPO BOOLEANO
# ---------------------------------------------------------------
# - Valores: True e False
# - Operadores lógicos: and, or, not, xor (^)
bateu_meta = ton_produzido >= ton_planejado
sem_parada = True
print(bateu_meta and sem_parada)   # produziu meta E sem parada?
print(bateu_meta or sem_parada)
print(not bateu_meta)
print(bateu_meta ^ sem_parada)     # xor


# ---------------------------------------------------------------
# INTERATIVIDADE — TERMINAL (input)
# ---------------------------------------------------------------
# Descomente para testar a leitura via terminal:
# produto = input('Digite o produto: ')
# print(f'Produção do {produto} registrada!')


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Dado ton_planejado=550 e ton_produzido=500, calcule e imprima,
#    com f-string, a eficiência em porcentagem com 1 casa decimal.
# 2) Extraia apenas o número "1004" do código de ordem "OP-1004".

# Resposta
ton_planejado = 550
ton_produzido = 500
print(f"Eficiência: {ton_produzido / ton_planejado:.1%}")

ordem = "OP-1004"
print("Número da OP:", ordem[3:])
