"""
=============================================================
 22. PANDAS — COMBINAÇÃO DE DADOS
=============================================================

Formas de juntar DataFrames:

    pd.concat()  -> empilha (vertical) ou cola lado a lado (horizontal)
    pd.merge()   -> junção por chave, estilo JOIN do SQL
    df.join()    -> junção pelo índice

Caso típico na fábrica: cruzar os apontamentos de produção com uma
tabela de cadastro dos produtos (família, preço por tonelada, etc.).
"""

import pandas as pd


# ---------------------------------------------------------------
# concat -> empilhar (axis=0): juntar apontamentos de dois meses
# ---------------------------------------------------------------
jan = pd.DataFrame({'produto': ['NPK 10-10-10', 'Ureia'], 'ton': [470, 590]})
fev = pd.DataFrame({'produto': ['MAP', 'KCl'], 'ton': [400, 540]})

print(pd.concat([jan, fev]))                     # empilha (vertical)
print(pd.concat([jan, fev], ignore_index=True))  # reindexando 0..n


# ---------------------------------------------------------------
# merge -> junção por coluna-chave (como JOIN no SQL)
# ---------------------------------------------------------------
producao = pd.read_csv('producao.csv')[['ordem_producao', 'produto', 'ton_produzido']]

# Tabela de cadastro dos produtos (família e preço por tonelada)
cadastro = pd.DataFrame({
    'produto': ['NPK 10-10-10', 'Ureia', 'MAP', 'KCl', 'Superfosfato Simples'],
    'familia': ['Formulado', 'Nitrogenado', 'Fosfatado', 'Potássico', 'Fosfatado'],
    'preco_ton': [2800, 2500, 3200, 3000, 1800]
})

# inner (default): só as ordens cujo produto existe no cadastro
juncao = pd.merge(producao, cadastro, on='produto', how='inner')
print(juncao.head())

# left: mantém TODAS as ordens; sem cadastro vira NaN
print(pd.merge(producao, cadastro, on='produto', how='left').head())

# Agora dá para calcular o valor produzido (R$)
juncao['valor_rs'] = juncao['ton_produzido'] * juncao['preco_ton']
print(juncao.groupby('familia')['valor_rs'].sum())


# ---------------------------------------------------------------
# join -> junção pelo índice
# ---------------------------------------------------------------
a = pd.DataFrame({'ton': [470, 590]}, index=['NPK 10-10-10', 'Ureia'])
b = pd.DataFrame({'preco_ton': [2800, 2500]}, index=['NPK 10-10-10', 'Ureia'])
print(a.join(b))


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Após o merge, mostre o valor total produzido (R$) por PRODUTO,
#    do maior para o menor.

# Resposta
print(juncao.groupby('produto')['valor_rs'].sum().sort_values(ascending=False))
