"""
=============================================================
 23. PANDAS — DATAS E SÉRIES TEMPORAIS
=============================================================

pandas tem suporte forte a datas (tipo datetime64), útil para analisar
a produção ao longo do tempo (por mês, por dia da semana, etc.).

    pd.to_datetime()  -> converte texto em data
    .dt               -> acessa partes da data (ano, mês, dia...)
    .resample()       -> reagrupa por período (dia, mês, ano...)
"""

import pandas as pd

df = pd.read_csv('producao.csv')
df['ton_produzido'] = df['ton_produzido'].fillna(0)


# ---------------------------------------------------------------
# Convertendo texto -> datetime
# ---------------------------------------------------------------
df['data'] = pd.to_datetime(df['data'])
print(df.dtypes)


# ---------------------------------------------------------------
# Acessando partes da data com .dt
# ---------------------------------------------------------------
df['ano'] = df['data'].dt.year
df['mes'] = df['data'].dt.month
df['dia_semana'] = df['data'].dt.day_name()
print(df[['data', 'ano', 'mes', 'dia_semana']].head())


# ---------------------------------------------------------------
# Filtro por data
# ---------------------------------------------------------------
print(df[df['data'] >= '2024-05-01'])               # produção a partir de maio
print(df[(df['data'] >= '2024-02-01') &
         (df['data'] <= '2024-03-31')])             # fev e mar


# ---------------------------------------------------------------
# resample -> agregar por período (precisa da data como índice)
# ---------------------------------------------------------------
df_idx = df.set_index('data')

# Total produzido por mês ('M' = month end)
# OBS: no pandas 2.2+ o alias passou a ser 'ME' (e 'YE' para ano).
print(df_idx['ton_produzido'].resample('M').sum())

# Total por ano ('Y' = year end)
print(df_idx['ton_produzido'].resample('Y').sum())


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Calcule o tempo de parada total (tempo_parada_min) por mês.

# Resposta
df['tempo_parada_min'] = df['tempo_parada_min'].fillna(0)
parada_mes = df.set_index('data')['tempo_parada_min'].resample('M').sum()
print(parada_mes)
