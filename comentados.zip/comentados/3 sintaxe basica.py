# COMENTÁRIOS

# comentário de uma linha
"""
Bloco de comentário em múltiplas linhas
Muito usado para Docstrings (documentação de funções, classes e módulos)
"""

# INDENTAÇÃO (BLOCOS)
for toneladas in [470, 500, 400, 595]:
    if toneladas % 50 == 0:
        print(toneladas, 't =>', toneladas // 50, 'lotes de 50 t')

# QUEBRA DE LINHA

# Quebra por contra-barra
custo_total = 1500 * 3 + \
    250 / 2

# Lista (quebra por vírgula)
produtos = ['NPK', 'Ureia', 'MAP',
            'KCl', 'Superfosfato Simples']

# Chamada de função (quebra por vírgula)
ordens = range(1001,
               1011)

print(custo_total, produtos, list(ordens))