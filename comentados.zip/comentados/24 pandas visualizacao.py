"""
=============================================================
 24. PANDAS — VISUALIZAÇÃO RÁPIDA
=============================================================

pandas tem o método .plot() integrado ao matplotlib, permitindo
gerar gráficos direto de uma Series ou DataFrame — ótimo para
montar rapidamente um painel de produção.

REQUER matplotlib:
    pip install matplotlib

Tipos de gráfico (parâmetro kind):
    'line'  (default) | 'bar' | 'barh' | 'hist' | 'box' | 'pie' | 'scatter'
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('producao.csv')
df['ton_produzido'] = df['ton_produzido'].fillna(0)
df['data'] = pd.to_datetime(df['data'])


# ---------------------------------------------------------------
# Gráfico de BARRAS — total produzido por produto
# ---------------------------------------------------------------
total_produto = df.groupby('produto')['ton_produzido'].sum()
total_produto.plot(kind='bar', title='Produção total por produto')
plt.ylabel('Toneladas')
plt.tight_layout()
plt.savefig('grafico_produto.png')   # salva em arquivo
plt.clf()                            # limpa a figura para o próximo gráfico
print("Gráfico salvo: grafico_produto.png")


# ---------------------------------------------------------------
# Gráfico de LINHA — produção ao longo dos meses
# ---------------------------------------------------------------
por_mes = df.set_index('data')['ton_produzido'].resample('M').sum()  # 'ME' no pandas 2.2+
por_mes.plot(kind='line', marker='o', title='Produção por mês')
plt.ylabel('Toneladas')
plt.tight_layout()
plt.savefig('grafico_mensal.png')
plt.clf()
print("Gráfico salvo: grafico_mensal.png")


# ---------------------------------------------------------------
# Gráfico de PIZZA — participação de cada linha na produção
# ---------------------------------------------------------------
por_linha = df.groupby('linha')['ton_produzido'].sum()
por_linha.plot(kind='pie', autopct='%1.1f%%', title='Participação por linha')
plt.ylabel('')
plt.tight_layout()
plt.savefig('grafico_linha.png')
plt.clf()
print("Gráfico salvo: grafico_linha.png")

# Para exibir na tela em vez de salvar, use:
#   plt.show()


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Gere um gráfico de barras do tempo de parada total por linha e
#    salve como 'grafico_parada_linha.png'.

# Resposta
df['tempo_parada_min'] = df['tempo_parada_min'].fillna(0)
parada_linha = df.groupby('linha')['tempo_parada_min'].sum()
parada_linha.plot(kind='bar', title='Parada total por linha')
plt.ylabel('Minutos')
plt.tight_layout()
plt.savefig('grafico_parada_linha.png')
plt.clf()
print("Gráfico salvo: grafico_parada_linha.png")
