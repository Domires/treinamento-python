"""
=============================================================
 7. LAÇOS DE REPETIÇÃO
=============================================================

Estruturas de repetição usadas para processar coleções de dados ou
executar blocos de código múltiplas vezes.
"""


# ---------------------------------------------------------------
# for
# ---------------------------------------------------------------
# Soma a produção de várias ordens (toneladas).
producao = [470, 590, 400, 540, 460]
total = 0
for ton in producao:
    total = total + ton
print('Total produzido:', total, 't')


# ---------------------------------------------------------------
# while
# ---------------------------------------------------------------
# Mesma soma, controlando o índice manualmente.
total = 0
i = 0
while i < len(producao):
    total = total + producao[i]
    i += 1
print('Total produzido:', total, 't')


# ---------------------------------------------------------------
# break, continue e pass
# ---------------------------------------------------------------
# - break    : encerra o loop imediatamente
# - continue : pula para a próxima iteração
# - pass     : não faz nada (placeholder)
#
# Percorre lotes; para no primeiro lote reprovado (refugo crítico).
lotes = ['OK', 'OK', 'OK', 'REPROVADO', 'OK']

for i, status in enumerate(lotes):
    if status == 'REPROVADO':
        print('Lote', i + 1, 'reprovado - parar inspeção')
        break
    else:
        print('Lote', i + 1, 'aprovado')
        pass


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------

oee_linhas = [0.8534, 0.7212, 0.9087, 0.6543, 0.8891]

# TODO 1: utilizando a mesma variável, ajuste cada OEE para conter
#         apenas 2 casas decimais.
# Dica: https://docs.python.org/3/library/functions.html#round

# Resposta
for i in range(len(oee_linhas)):
    oee_linhas[i] = round(oee_linhas[i], 2)
print(oee_linhas)


# TODO 2: percorra as ordens de 1001 a 1014 (use range(1001, 1015)).
# Quando o número da OP for PAR: print("OP par:", op) e vá para o início do laço.
# Ao encontrar a OP 1012: print("OP 1012 encontrada") e encerre o loop.

# Resposta
for op in range(1001, 1015):
    if op == 1012:
        print("OP 1012 encontrada")
        break
    if op % 2 == 0:
        print("OP par:", op)
else:
    print("OP 1012 não encontrada")
