"""
=============================================================
 14. PANDAS — SERIES
=============================================================

Series é um vetor 1D rotulado: cada valor tem um índice (rótulo).
Pense nela como uma única coluna de uma tabela (ex.: o OEE por linha).

Sintaxe: pd.Series(dados, index=rotulos)
"""

import pandas as pd


# ---------------------------------------------------------------
# Criação
# ---------------------------------------------------------------
# A partir de uma lista (índice numérico automático: 0, 1, 2...)
s = pd.Series([470, 590, 400, 540])
print(s)

# Com índice personalizado (OEE por linha)
oee = pd.Series([0.85, 0.72, 0.91], index=['Granulacao', 'Mistura', 'Ensaque'])
print(oee)

# A partir de um dicionário (as chaves viram o índice)
capacidade = pd.Series({'Granulacao': 500, 'Mistura': 600, 'Ensaque': 300})
print(capacidade)


# ---------------------------------------------------------------
# Acesso
# ---------------------------------------------------------------
print(oee['Granulacao'])   # acesso por rótulo
print(oee.iloc[0])         # acesso por posição
print(oee[oee > 0.80])     # filtro booleano (linhas com OEE > 80%)


# ---------------------------------------------------------------
# Operações vetorizadas (aplicadas a todos os elementos de uma vez)
# ---------------------------------------------------------------
print(oee * 100)           # OEE em porcentagem
print(capacidade - 50)     # reduz 50 t de capacidade em todas as linhas


# ---------------------------------------------------------------
# Métodos úteis / estatísticas
# ---------------------------------------------------------------
print('OEE médio :', oee.mean())
print('OEE máximo:', oee.max())
print('Melhor linha:', oee.idxmax())
print(oee.describe())      # resumo estatístico


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Dada a Series de toneladas por turno, mostre os turnos que
#    produziram MAIS que a média.

por_turno = pd.Series({'A': 470, 'B': 590, 'C': 400})

# Resposta
print(por_turno[por_turno > por_turno.mean()])
