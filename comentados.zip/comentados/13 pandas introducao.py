"""
=============================================================
 13. PANDAS — INTRODUÇÃO
=============================================================

pandas é a principal biblioteca Python para análise e manipulação
de dados tabulares (linhas e colunas, como uma planilha ou tabela SQL).
É a ferramenta-chave para analisar os apontamentos de produção da fábrica.

POR QUE USAR
- Lê/escreve diversos formatos: CSV, Excel, JSON, SQL, etc.
- Operações vetorizadas (rápidas) sobre colunas inteiras.
- Ferramentas prontas: filtros, agrupamentos, junções, datas.

INSTALAÇÃO (terminal):
    pip install pandas

ESTRUTURAS PRINCIPAIS
- Series    : vetor 1D rotulado (uma coluna).
- DataFrame : tabela 2D rotulada (várias colunas). É o objeto central.

Convenção universal de import:
    import pandas as pd

Referência: https://pandas.pydata.org/docs/
"""

import pandas as pd

print("Versão do pandas:", pd.__version__)


# ---------------------------------------------------------------
# Series — uma coluna rotulada (ex.: toneladas por produto)
# ---------------------------------------------------------------
s = pd.Series([470, 590, 400], index=['NPK 10-10-10', 'Ureia', 'MAP'])
print(s)


# ---------------------------------------------------------------
# DataFrame — uma tabela (ex.: ordens de produção)
# ---------------------------------------------------------------
df = pd.DataFrame({
    'ordem_producao': ['OP-1001', 'OP-1002', 'OP-1003'],
    'produto': ['NPK 10-10-10', 'Ureia', 'MAP'],
    'ton_produzido': [470, 590, 400]
})
print(df)


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Crie uma Series com a capacidade nominal (t) de 3 linhas:
#    Granulacao=500, Mistura=600, Ensaque=300. Imprima a maior.

# Resposta
cap = pd.Series([500, 600, 300], index=['Granulacao', 'Mistura', 'Ensaque'])
print("Maior capacidade:", cap.max(), "t na", cap.idxmax())
