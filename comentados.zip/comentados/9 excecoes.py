"""
=============================================================
 9. EXCEÇÕES
=============================================================

Tratamento de erros com try / except / else / finally.

- try     : bloco que pode gerar um erro
- except  : captura e trata o erro
- else    : executa se NÃO ocorreu erro
- finally : sempre executa, com ou sem erro

Útil quando lemos dados de produção que podem vir errados (ex.: meta
planejada zerada, texto onde deveria haver número, etc.).
"""


# ---------------------------------------------------------------
# Exemplo: divisão por zero (meta planejada zerada)
# ---------------------------------------------------------------
def calcular_aproveitamento(ton_produzido, ton_planejado):
    try:
        aproveitamento = ton_produzido / ton_planejado * 100
    except ZeroDivisionError:
        print("Erro: meta planejada (ton_planejado) está zerada!")
        return None
    except Exception as e:
        print(f"Erro inesperado: {e}")
        return None
    else:
        print("Cálculo realizado com sucesso.")
        return aproveitamento
    finally:
        print("Fim do cálculo (com ou sem erro).")

print(calcular_aproveitamento(470, 0))     # dispara ZeroDivisionError
print(calcular_aproveitamento(470, 500))   # caminho de sucesso


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) A leitura do sensor de toneladas pode vir como texto inválido.
#    Converta o valor para float com try/except; se falhar, imprima
#    "Leitura inválida" e use 0.0.

leitura = "470,5"   # veio com vírgula -> float() vai falhar

# Resposta
try:
    valor = float(leitura)
except ValueError:
    print("Leitura inválida")
    valor = 0.0
print("Valor usado:", valor)
