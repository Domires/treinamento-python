"""
=============================================================
 21. PANDAS — AGREGAÇÃO E AGRUPAMENTO
=============================================================

Agrupar = dividir os dados em grupos, aplicar um cálculo a cada grupo
e combinar os resultados (padrão "split-apply-combine").
Ex.: total produzido por produto, OEE médio por linha, etc.

    df.groupby('coluna')          -> cria os grupos
    .sum() / .mean() / .count()   -> agrega cada grupo
    .agg(...)                     -> várias agregações de uma vez
    df['col'].value_counts()      -> conta ocorrências
    pd.pivot_table(...)           -> tabela dinâmica (cruza dimensões)
"""

import pandas as pd

df = pd.read_csv('producao.csv')
df['ton_produzido'] = df['ton_produzido'].fillna(0)


# ---------------------------------------------------------------
# value_counts -> frequência de cada valor
# ---------------------------------------------------------------
print(df['produto'].value_counts())   # nº de OPs por produto
print(df['turno'].value_counts())     # nº de OPs por turno


# ---------------------------------------------------------------
# groupby + agregação
# ---------------------------------------------------------------
# Total produzido por produto
print(df.groupby('produto')['ton_produzido'].sum())

# Produção média por linha
print(df.groupby('linha')['ton_produzido'].mean())

# Agrupar por mais de uma coluna (produto x turno)
print(df.groupby(['produto', 'turno'])['ton_produzido'].sum())


# ---------------------------------------------------------------
# .agg() -> várias agregações ao mesmo tempo
# ---------------------------------------------------------------
print(df.groupby('produto').agg(
    total_produzido=('ton_produzido', 'sum'),
    media_por_op=('ton_produzido', 'mean'),
    qtd_ops=('ton_produzido', 'count'),
    parada_total=('tempo_parada_min', 'sum')
))


# ---------------------------------------------------------------
# pivot_table -> tabela dinâmica (linhas x colunas)
# ---------------------------------------------------------------
tabela = pd.pivot_table(
    df,
    values='ton_produzido',
    index='produto',      # linhas
    columns='turno',      # colunas
    aggfunc='sum',
    fill_value=0
)
print(tabela)


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Qual produto teve a MAIOR parada total (soma de tempo_parada_min)?

# Resposta
parada_por_produto = df.groupby('produto')['tempo_parada_min'].sum()
print(parada_por_produto)
print("Maior parada:", parada_por_produto.idxmax())
