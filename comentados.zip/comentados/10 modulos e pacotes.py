"""
=============================================================
 10. MÓDULOS E PACOTES
=============================================================

Pacotes são arquivos/bibliotecas que podem ser importados.
São objetos Singleton (uma única instância em memória por programa).

Referência: https://pypi.org

----------------------------------------------------------------
FORMAS DE IMPORTAR
----------------------------------------------------------------
    import pandas
    from collections import Counter
    from collections import *   # não recomendado — polui o namespace

----------------------------------------------------------------
GERENCIAMENTO COM pip (comandos de terminal)
----------------------------------------------------------------
    pip list                        # lista pacotes instalados
    pip install <nome>              # instala pacote
    pip uninstall <nome>            # desinstala pacote
    pip freeze > requirements.txt   # exporta dependências

----------------------------------------------------------------
CRIANDO E USANDO UM MÓDULO PRÓPRIO
----------------------------------------------------------------
Criar arquivo `indicadores.py` com:

    def media(lista):
        return sum(lista) / len(lista)

Importar e usar:

    import indicadores
    print(indicadores.media([470, 590, 400]))
"""

# ---------------------------------------------------------------
# Exemplo: importando módulos da biblioteca padrão
# ---------------------------------------------------------------
from collections import Counter

produzidos = ['NPK 10-10-10', 'Ureia', 'NPK 10-10-10', 'MAP', 'Ureia', 'NPK 10-10-10']
contagem = Counter(produzidos)
print(contagem)                 # quantas OPs por produto
print(contagem.most_common(1))  # produto mais produzido


# ---------------------------------------------------------------
# Exemplo: função de módulo próprio (média de toneladas)
# ---------------------------------------------------------------
def media(lista):
    return sum(lista) / len(lista)

producao = [470, 590, 400, 540, 460]
print("Média de produção:", media(producao), "t")


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Use Counter para descobrir quantas OPs rodaram em cada linha.
# 2) Mostre a linha com mais ordens.

linhas = ['Granulacao', 'Mistura', 'Granulacao', 'Granulacao', 'Mistura']

# Resposta
cont_linhas = Counter(linhas)
print(cont_linhas)
print("Linha com mais OPs:", cont_linhas.most_common(1)[0][0])
