"""
=============================================================
 16. PANDAS — LEITURA E ESCRITA (I/O)
=============================================================

pandas lê e escreve vários formatos. Os mais comuns:

LEITURA                       ESCRITA
    pd.read_csv()                 df.to_csv()
    pd.read_excel()               df.to_excel()
    pd.read_json()                df.to_json()
    pd.read_sql()                 df.to_sql()

Este arquivo usa o dataset de exemplo "producao.csv" (mesma pasta),
com apontamentos de ordens de produção da fábrica.

OBS: read_excel/to_excel exigem o pacote `openpyxl`:
    pip install openpyxl
"""

import pandas as pd


# ---------------------------------------------------------------
# LEITURA de CSV
# ---------------------------------------------------------------
df = pd.read_csv('producao.csv')
print(df.head())

# Parâmetros úteis de read_csv:
#   sep=';'              -> separador (CSV exportado do Excel BR usa ;)
#   decimal=','          -> vírgula como separador decimal
#   encoding='latin-1'   -> codificação de arquivos com acentos
#   parse_dates=['data'] -> já converte a coluna em datetime
df_datas = pd.read_csv('producao.csv', parse_dates=['data'])
print(df_datas.dtypes)


# ---------------------------------------------------------------
# ESCRITA de CSV
# ---------------------------------------------------------------
# Cria uma coluna nova (tempo operando) e salva um novo arquivo
df['tempo_operando_min'] = df['tempo_planejado_min'] - df['tempo_parada_min']
df.to_csv('producao_tratada.csv', index=False)  # index=False não grava o índice
print("Arquivo 'producao_tratada.csv' salvo.")


# ---------------------------------------------------------------
# ESCRITA / LEITURA de Excel (requer openpyxl)
# ---------------------------------------------------------------
# df.to_excel('producao.xlsx', index=False, sheet_name='Producao')
# df_xlsx = pd.read_excel('producao.xlsx', sheet_name='Producao')
# print(df_xlsx.head())


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Leia o producao.csv, mantenha só as colunas 'ordem_producao',
#    'produto' e 'ton_produzido' e salve em 'resumo_ops.csv'.

# Resposta
resumo = pd.read_csv('producao.csv')[['ordem_producao', 'produto', 'ton_produzido']]
resumo.to_csv('resumo_ops.csv', index=False)
print("resumo_ops.csv salvo com", len(resumo), "linhas.")
