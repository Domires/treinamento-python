"""
=============================================================
 19. PANDAS — LIMPEZA DE DADOS
=============================================================

Dados reais (apontamentos de chão de fábrica) costumam ter problemas:
valores nulos, duplicatas, tipos errados, nomes inconsistentes.
Limpar é etapa essencial antes de qualquer análise.

O dataset "producao.csv" foi montado com nulos e uma duplicata
PROPOSITAIS para os exemplos abaixo:
  - ton_produzido faltando em uma OP
  - linha em branco em uma OP
  - tempo_parada_min faltando em uma OP
  - uma OP lançada em duplicidade
"""

import pandas as pd

df = pd.read_csv('producao.csv')


# ---------------------------------------------------------------
# VALORES NULOS (NaN)
# ---------------------------------------------------------------
print(df.isna().sum())            # conta nulos por coluna
print(df[df['linha'].isna()])     # ordens sem linha apontada

# Preencher nulos
df['ton_produzido'] = df['ton_produzido'].fillna(0)            # produção -> 0
df['tempo_parada_min'] = df['tempo_parada_min'].fillna(0)      # sem parada -> 0
df['linha'] = df['linha'].fillna('Não informada')             # linha -> texto
print(df.isna().sum())

# Alternativa: remover linhas com nulos
# df_sem_nulos = df.dropna()                  # remove linha com qualquer nulo
# df_sem_nulos = df.dropna(subset=['linha'])  # só onde 'linha' é nulo


# ---------------------------------------------------------------
# DUPLICATAS (mesma OP lançada duas vezes)
# ---------------------------------------------------------------
print('Linhas duplicadas:', df.duplicated().sum())
print(df[df.duplicated(keep=False)])     # mostra todas as duplicatas
df = df.drop_duplicates()                # remove duplicatas
print('Após remover:', df.duplicated().sum())


# ---------------------------------------------------------------
# CONVERSÃO DE TIPOS
# ---------------------------------------------------------------
print(df.dtypes)
df['ton_produzido'] = df['ton_produzido'].astype(int)   # float -> int
df['data'] = pd.to_datetime(df['data'])                 # texto -> datetime
print(df.dtypes)


# ---------------------------------------------------------------
# RENOMEAR COLUNAS
# ---------------------------------------------------------------
df = df.rename(columns={'ton_produzido': 'toneladas',
                        'tempo_parada_min': 'parada_min'})
print(df.columns.tolist())


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Recarregue o producao.csv e conte quantas ordens ficaram SEM
#    apontamento de toneladas (ton_produzido nulo) antes de tratar.

# Resposta
bruto = pd.read_csv('producao.csv')
print("OPs sem toneladas:", bruto['ton_produzido'].isna().sum())
