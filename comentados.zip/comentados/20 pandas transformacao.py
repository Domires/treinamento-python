"""
=============================================================
 20. PANDAS — TRANSFORMAÇÃO DE DADOS
=============================================================

Transformar = criar/modificar colunas e reorganizar os dados.
Aqui montamos os indicadores de produção a partir dos apontamentos.

    nova coluna   -> df['nova'] = ...
    .apply()      -> aplica função a cada linha/elemento
    .map()        -> mapeia valores de uma Series (substituição)
    .assign()     -> cria colunas retornando novo DataFrame
    .sort_values()-> ordena por coluna(s)
"""

import pandas as pd

df = pd.read_csv('producao.csv')
df['ton_produzido'] = df['ton_produzido'].fillna(0)
df['tempo_parada_min'] = df['tempo_parada_min'].fillna(0)


# ---------------------------------------------------------------
# Criar colunas a partir de outras (operação vetorizada)
# Componentes do OEE:
#   Disponibilidade = (tempo planejado - parada) / tempo planejado
#   Performance     = produzido / planejado
#   Qualidade       = lotes aprovados / lotes totais
# ---------------------------------------------------------------
df['disponibilidade'] = (df['tempo_planejado_min'] - df['tempo_parada_min']) / df['tempo_planejado_min']
df['performance'] = df['ton_produzido'] / df['ton_planejado']
df['qualidade'] = df['lotes_aprovados'] / df['lotes_total']
df['oee'] = df['disponibilidade'] * df['performance'] * df['qualidade']
print(df[['ordem_producao', 'disponibilidade', 'performance', 'qualidade', 'oee']].head())


# ---------------------------------------------------------------
# .apply() -> aplica uma função a cada valor de uma coluna
# ---------------------------------------------------------------
def classificar_oee(valor):
    if valor < 0.65:
        return 'Baixo'
    elif valor < 0.85:
        return 'Bom'
    return 'Classe mundial'

df['classe_oee'] = df['oee'].apply(classificar_oee)
print(df[['ordem_producao', 'oee', 'classe_oee']].head())


# ---------------------------------------------------------------
# .map() -> substitui valores conforme um dicionário
# ---------------------------------------------------------------
sigla_linha = {'Granulacao': 'GR', 'Mistura': 'MI'}
df['linha_sigla'] = df['linha'].map(sigla_linha)
print(df[['linha', 'linha_sigla']].head())


# ---------------------------------------------------------------
# .assign() -> cria colunas retornando um novo DataFrame (encadeável)
# ---------------------------------------------------------------
df2 = df.assign(oee_pct=(df['oee'] * 100).round(1))
print(df2[['ordem_producao', 'oee_pct']].head())


# ---------------------------------------------------------------
# Ordenação
# ---------------------------------------------------------------
print(df.sort_values('oee', ascending=False).head())     # melhores OEE
print(df.sort_values(['linha', 'oee'],                    # por linha, pior OEE
                     ascending=[True, True]).head())


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Crie a coluna 'ton_perdida' = ton_planejado - ton_produzido e
#    mostre as 3 ordens com maior perda.

# Resposta
df['ton_perdida'] = df['ton_planejado'] - df['ton_produzido']
print(df.sort_values('ton_perdida', ascending=False)
        [['ordem_producao', 'produto', 'ton_perdida']].head(3))
