"""
=============================================================
 6. CONTROLE DE FLUXO
=============================================================
"""


# ---------------------------------------------------------------
# if / elif / else
# ---------------------------------------------------------------
# Execução condicional de blocos de código.
#
# OBS: Python não faz coerções automáticas — é necessário converter
# o tipo explicitamente (int(), float(), etc.).
#
# Aqui classificamos o OEE (Overall Equipment Effectiveness) de uma OP.

oee = int(input('Entre com o OEE (%) da ordem de produção: '))

if oee < 50:
    print('Crítico - investigar a linha')
elif 50 <= oee < 65:
    print('Baixo')
elif 65 <= oee < 75:
    print('Aceitável')
elif 75 <= oee < 85:
    print('Bom')
else:
    print('Classe mundial!')


# ---------------------------------------------------------------
# EXPRESSÕES TERNÁRIAS
# ---------------------------------------------------------------
# Condicional em uma única linha.
# Sintaxe:
#   <variável> = <valor_se_verdadeiro> if <condição> else <valor_se_falso>

ton_produzido = 470
ton_planejado = 500
status = 'Meta batida' if ton_produzido >= ton_planejado else 'Abaixo da meta'
print(status)


# ---------------------------------------------------------------
# match (Python 3.10+)
# ---------------------------------------------------------------
# Semelhante ao `switch` de outras linguagens, mas com suporte a
# pattern matching. Ex.: descrição padrão para o motivo da parada.

def descricao_parada(codigo):
    match codigo:
        case 10:
            return "Manutenção preventiva"
        case 20:
            return "Falta de matéria-prima"
        case 30:
            return "Troca de produto (setup)"
        case _:
            return "Motivo não catalogado"

print(descricao_parada(20))
print(descricao_parada(99))


# ---------------------------------------------------------------
# EXERCÍCIOS
# ---------------------------------------------------------------
# 1) Dada a quantidade de lotes reprovados, imprima:
#    0          -> "Qualidade OK"
#    1 ou 2     -> "Atenção"
#    3 ou mais  -> "Bloquear OP"
#    Use if/elif/else.

reprovados = 2

# Resposta
if reprovados == 0:
    print("Qualidade OK")
elif reprovados <= 2:
    print("Atenção")
else:
    print("Bloquear OP")
